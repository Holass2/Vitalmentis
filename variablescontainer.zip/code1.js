gdjs.QuestionsCode = {};
gdjs.QuestionsCode.localVariables = [];
gdjs.QuestionsCode.GDCount_9595of_9595questionsObjects1= [];
gdjs.QuestionsCode.GDCount_9595of_9595questionsObjects2= [];
gdjs.QuestionsCode.GDCount_9595of_9595questionsObjects3= [];
gdjs.QuestionsCode.GDQuestionObjects1= [];
gdjs.QuestionsCode.GDQuestionObjects2= [];
gdjs.QuestionsCode.GDQuestionObjects3= [];
gdjs.QuestionsCode.GDAnswerButtonObjects1= [];
gdjs.QuestionsCode.GDAnswerButtonObjects2= [];
gdjs.QuestionsCode.GDAnswerButtonObjects3= [];
gdjs.QuestionsCode.GDTransition1Objects1= [];
gdjs.QuestionsCode.GDTransition1Objects2= [];
gdjs.QuestionsCode.GDTransition1Objects3= [];
gdjs.QuestionsCode.GDNextObjects1= [];
gdjs.QuestionsCode.GDNextObjects2= [];
gdjs.QuestionsCode.GDNextObjects3= [];
gdjs.QuestionsCode.GDTransition2Objects1= [];
gdjs.QuestionsCode.GDTransition2Objects2= [];
gdjs.QuestionsCode.GDTransition2Objects3= [];
gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects1= [];
gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2= [];
gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects3= [];
gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects1= [];
gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2= [];
gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects3= [];
gdjs.QuestionsCode.GDTiled_9595BackgroundObjects1= [];
gdjs.QuestionsCode.GDTiled_9595BackgroundObjects2= [];
gdjs.QuestionsCode.GDTiled_9595BackgroundObjects3= [];
gdjs.QuestionsCode.GDGradientObjects1= [];
gdjs.QuestionsCode.GDGradientObjects2= [];
gdjs.QuestionsCode.GDGradientObjects3= [];


gdjs.QuestionsCode.mapOfGDgdjs_9546QuestionsCode_9546GDAnswerButtonObjects1Objects = Hashtable.newFrom({"AnswerButton": gdjs.QuestionsCode.GDAnswerButtonObjects1});
gdjs.QuestionsCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.QuestionsCode.GDAnswerButtonObjects1, gdjs.QuestionsCode.GDAnswerButtonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.QuestionsCode.GDAnswerButtonObjects2.length;i<l;++i) {
    if ( gdjs.QuestionsCode.GDAnswerButtonObjects2[i].getVariableNumber(gdjs.QuestionsCode.GDAnswerButtonObjects2[i].getVariables().getFromIndex(0)) == runtimeScene.getGame().getVariables().getFromIndex(0).getChild(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber()).getChild("RightAnswerIndex").getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.QuestionsCode.GDAnswerButtonObjects2[k] = gdjs.QuestionsCode.GDAnswerButtonObjects2[i];
        ++k;
    }
}
gdjs.QuestionsCode.GDAnswerButtonObjects2.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Success", false, 100, 1);
}}

}


{

gdjs.copyArray(gdjs.QuestionsCode.GDAnswerButtonObjects1, gdjs.QuestionsCode.GDAnswerButtonObjects2);

gdjs.copyArray(runtimeScene.getObjects("Wrong_CheckMark"), gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.QuestionsCode.GDAnswerButtonObjects2.length;i<l;++i) {
    if ( gdjs.QuestionsCode.GDAnswerButtonObjects2[i].getVariableNumber(gdjs.QuestionsCode.GDAnswerButtonObjects2[i].getVariables().getFromIndex(0)) != runtimeScene.getGame().getVariables().getFromIndex(0).getChild(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber()).getChild("RightAnswerIndex").getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.QuestionsCode.GDAnswerButtonObjects2[k] = gdjs.QuestionsCode.GDAnswerButtonObjects2[i];
        ++k;
    }
}
gdjs.QuestionsCode.GDAnswerButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2.length;i<l;++i) {
    if ( gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2[i].getVariableNumber(gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2[i].getVariables().getFromIndex(0)) == ((gdjs.QuestionsCode.GDAnswerButtonObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.QuestionsCode.GDAnswerButtonObjects2[0].getVariables()).getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2[k] = gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2[i];
        ++k;
    }
}
gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2 */
{for(var i = 0, len = gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2.length ;i < len;++i) {
    gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2.length ;i < len;++i) {
    gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2.length ;i < len;++i) {
    gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2[i].getBehavior("Resizable").setWidth(10);
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2.length ;i < len;++i) {
    gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2[i].getBehavior("Tween").addObjectOpacityTween2("appear-opacity", 255, "easeInOutExpo", 0.4, false);
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2.length ;i < len;++i) {
    gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2[i].getBehavior("Tween").addObjectWidthTween2("appear", 80, "easeInOutQuint", 0.4, false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "FalseSound", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Correct_CheckMark"), gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2.length;i<l;++i) {
    if ( gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2[i].getVariableNumber(gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2[i].getVariables().getFromIndex(0)) == runtimeScene.getGame().getVariables().getFromIndex(0).getChild(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber()).getChild("RightAnswerIndex").getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2[k] = gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2[i];
        ++k;
    }
}
gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2 */
{for(var i = 0, len = gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2.length ;i < len;++i) {
    gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2.length ;i < len;++i) {
    gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2[i].getBehavior("Resizable").setWidth(10);
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2.length ;i < len;++i) {
    gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2.length ;i < len;++i) {
    gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2[i].getBehavior("Tween").addObjectWidthTween2("appear", 95, "easeInOutExpo", 0.4, false);
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2.length ;i < len;++i) {
    gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2[i].getBehavior("Tween").addObjectOpacityTween2("appear-opacity", 255, "easeInOutExpo", 0.4, false);
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.QuestionsCode.GDAnswerButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.QuestionsCode.GDNextObjects1);
{gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.QuestionsCode.mapOfGDgdjs_9546QuestionsCode_9546GDAnswerButtonObjects1Objects);
}{for(var i = 0, len = gdjs.QuestionsCode.GDAnswerButtonObjects1.length ;i < len;++i) {
    gdjs.QuestionsCode.GDAnswerButtonObjects1[i].Activate(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.QuestionsCode.GDNextObjects1[i].hide(false);
}
}}

}


};gdjs.QuestionsCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(0));
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Finished", false);
}}

}


};gdjs.QuestionsCode.asyncCallback10191100 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.QuestionsCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("AnswerButton"), gdjs.QuestionsCode.GDAnswerButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Correct_CheckMark"), gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2);
gdjs.copyArray(runtimeScene.getObjects("Transition2"), gdjs.QuestionsCode.GDTransition2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Wrong_CheckMark"), gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2);
{for(var i = 0, len = gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2.length ;i < len;++i) {
    gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2.length ;i < len;++i) {
    gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2[i].hide();
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.QuestionsCode.GDTransition2Objects2.length ;i < len;++i) {
    gdjs.QuestionsCode.GDTransition2Objects2[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Horizontal", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDAnswerButtonObjects2.length ;i < len;++i) {
    gdjs.QuestionsCode.GDAnswerButtonObjects2[i].Activate(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.QuestionsCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.QuestionsCode.localVariables.length = 0;
}
gdjs.QuestionsCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.QuestionsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.48), (runtimeScene) => (gdjs.QuestionsCode.asyncCallback10191100(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.QuestionsCode.eventsList3 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Correct_CheckMark"), gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects1);
gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.QuestionsCode.GDNextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tiled_Background"), gdjs.QuestionsCode.GDTiled_9595BackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Transition1"), gdjs.QuestionsCode.GDTransition1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Wrong_CheckMark"), gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{for(var i = 0, len = gdjs.QuestionsCode.GDTransition1Objects1.length ;i < len;++i) {
    gdjs.QuestionsCode.GDTransition1Objects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Circular", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.QuestionsCode.GDNextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects1.length ;i < len;++i) {
    gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects1.length ;i < len;++i) {
    gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDTiled_9595BackgroundObjects1.length ;i < len;++i) {
    gdjs.QuestionsCode.GDTiled_9595BackgroundObjects1[i].getBehavior("Opacity").setOpacity(75);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("AnswerButton"), gdjs.QuestionsCode.GDAnswerButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Count_of_questions"), gdjs.QuestionsCode.GDCount_9595of_9595questionsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Question"), gdjs.QuestionsCode.GDQuestionObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tiled_Background"), gdjs.QuestionsCode.GDTiled_9595BackgroundObjects1);
{for(var i = 0, len = gdjs.QuestionsCode.GDQuestionObjects1.length ;i < len;++i) {
    gdjs.QuestionsCode.GDQuestionObjects1[i].setBBText(runtimeScene.getGame().getVariables().getFromIndex(0).getChild(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber()).getChild("Question").getAsString());
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDAnswerButtonObjects1.length ;i < len;++i) {
    gdjs.QuestionsCode.GDAnswerButtonObjects1[i].SetLabelText(runtimeScene.getGame().getVariables().getFromIndex(0).getChild(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber()).getChild("Answers").getChild(gdjs.QuestionsCode.GDAnswerButtonObjects1[i].getVariables().getFromIndex(0).getAsNumber()).getAsString(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDCount_9595of_9595questionsObjects1.length ;i < len;++i) {
    gdjs.QuestionsCode.GDCount_9595of_9595questionsObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() + 1) + "/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDTiled_9595BackgroundObjects1.length ;i < len;++i) {
    gdjs.QuestionsCode.GDTiled_9595BackgroundObjects1[i].setXOffset(gdjs.QuestionsCode.GDTiled_9595BackgroundObjects1[i].getXOffset() - (gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene) * 3));
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDTiled_9595BackgroundObjects1.length ;i < len;++i) {
    gdjs.QuestionsCode.GDTiled_9595BackgroundObjects1[i].setYOffset(gdjs.QuestionsCode.GDTiled_9595BackgroundObjects1[i].getYOffset() - (gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene) * 3));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("AnswerButton"), gdjs.QuestionsCode.GDAnswerButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.QuestionsCode.GDAnswerButtonObjects1.length;i<l;++i) {
    if ( gdjs.QuestionsCode.GDAnswerButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.QuestionsCode.GDAnswerButtonObjects1[k] = gdjs.QuestionsCode.GDAnswerButtonObjects1[i];
        ++k;
    }
}
gdjs.QuestionsCode.GDAnswerButtonObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.QuestionsCode.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.QuestionsCode.GDNextObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.QuestionsCode.GDNextObjects1.length;i<l;++i) {
    if ( gdjs.QuestionsCode.GDNextObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.QuestionsCode.GDNextObjects1[k] = gdjs.QuestionsCode.GDNextObjects1[i];
        ++k;
    }
}
gdjs.QuestionsCode.GDNextObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.QuestionsCode.GDNextObjects1.length;i<l;++i) {
    if ( gdjs.QuestionsCode.GDNextObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.QuestionsCode.GDNextObjects1[k] = gdjs.QuestionsCode.GDNextObjects1[i];
        ++k;
    }
}
gdjs.QuestionsCode.GDNextObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.QuestionsCode.GDNextObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Transition1"), gdjs.QuestionsCode.GDTransition1Objects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "TransitionSound", false, 100, 1);
}{for(var i = 0, len = gdjs.QuestionsCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.QuestionsCode.GDNextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.QuestionsCode.GDTransition1Objects1.length ;i < len;++i) {
    gdjs.QuestionsCode.GDTransition1Objects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.49, "Horizontal", "Forward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.QuestionsCode.eventsList2(runtimeScene);} //End of subevents
}

}


};

gdjs.QuestionsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.QuestionsCode.GDCount_9595of_9595questionsObjects1.length = 0;
gdjs.QuestionsCode.GDCount_9595of_9595questionsObjects2.length = 0;
gdjs.QuestionsCode.GDCount_9595of_9595questionsObjects3.length = 0;
gdjs.QuestionsCode.GDQuestionObjects1.length = 0;
gdjs.QuestionsCode.GDQuestionObjects2.length = 0;
gdjs.QuestionsCode.GDQuestionObjects3.length = 0;
gdjs.QuestionsCode.GDAnswerButtonObjects1.length = 0;
gdjs.QuestionsCode.GDAnswerButtonObjects2.length = 0;
gdjs.QuestionsCode.GDAnswerButtonObjects3.length = 0;
gdjs.QuestionsCode.GDTransition1Objects1.length = 0;
gdjs.QuestionsCode.GDTransition1Objects2.length = 0;
gdjs.QuestionsCode.GDTransition1Objects3.length = 0;
gdjs.QuestionsCode.GDNextObjects1.length = 0;
gdjs.QuestionsCode.GDNextObjects2.length = 0;
gdjs.QuestionsCode.GDNextObjects3.length = 0;
gdjs.QuestionsCode.GDTransition2Objects1.length = 0;
gdjs.QuestionsCode.GDTransition2Objects2.length = 0;
gdjs.QuestionsCode.GDTransition2Objects3.length = 0;
gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects1.length = 0;
gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2.length = 0;
gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects3.length = 0;
gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects1.length = 0;
gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2.length = 0;
gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects3.length = 0;
gdjs.QuestionsCode.GDTiled_9595BackgroundObjects1.length = 0;
gdjs.QuestionsCode.GDTiled_9595BackgroundObjects2.length = 0;
gdjs.QuestionsCode.GDTiled_9595BackgroundObjects3.length = 0;
gdjs.QuestionsCode.GDGradientObjects1.length = 0;
gdjs.QuestionsCode.GDGradientObjects2.length = 0;
gdjs.QuestionsCode.GDGradientObjects3.length = 0;

gdjs.QuestionsCode.eventsList3(runtimeScene);
gdjs.QuestionsCode.GDCount_9595of_9595questionsObjects1.length = 0;
gdjs.QuestionsCode.GDCount_9595of_9595questionsObjects2.length = 0;
gdjs.QuestionsCode.GDCount_9595of_9595questionsObjects3.length = 0;
gdjs.QuestionsCode.GDQuestionObjects1.length = 0;
gdjs.QuestionsCode.GDQuestionObjects2.length = 0;
gdjs.QuestionsCode.GDQuestionObjects3.length = 0;
gdjs.QuestionsCode.GDAnswerButtonObjects1.length = 0;
gdjs.QuestionsCode.GDAnswerButtonObjects2.length = 0;
gdjs.QuestionsCode.GDAnswerButtonObjects3.length = 0;
gdjs.QuestionsCode.GDTransition1Objects1.length = 0;
gdjs.QuestionsCode.GDTransition1Objects2.length = 0;
gdjs.QuestionsCode.GDTransition1Objects3.length = 0;
gdjs.QuestionsCode.GDNextObjects1.length = 0;
gdjs.QuestionsCode.GDNextObjects2.length = 0;
gdjs.QuestionsCode.GDNextObjects3.length = 0;
gdjs.QuestionsCode.GDTransition2Objects1.length = 0;
gdjs.QuestionsCode.GDTransition2Objects2.length = 0;
gdjs.QuestionsCode.GDTransition2Objects3.length = 0;
gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects1.length = 0;
gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects2.length = 0;
gdjs.QuestionsCode.GDCorrect_9595CheckMarkObjects3.length = 0;
gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects1.length = 0;
gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects2.length = 0;
gdjs.QuestionsCode.GDWrong_9595CheckMarkObjects3.length = 0;
gdjs.QuestionsCode.GDTiled_9595BackgroundObjects1.length = 0;
gdjs.QuestionsCode.GDTiled_9595BackgroundObjects2.length = 0;
gdjs.QuestionsCode.GDTiled_9595BackgroundObjects3.length = 0;
gdjs.QuestionsCode.GDGradientObjects1.length = 0;
gdjs.QuestionsCode.GDGradientObjects2.length = 0;
gdjs.QuestionsCode.GDGradientObjects3.length = 0;


return;

}

gdjs['QuestionsCode'] = gdjs.QuestionsCode;
