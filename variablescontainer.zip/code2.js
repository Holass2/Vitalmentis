gdjs.FinishedCode = {};
gdjs.FinishedCode.localVariables = [];
gdjs.FinishedCode.GDFinalScoreTextObjects1= [];
gdjs.FinishedCode.GDFinalScoreTextObjects2= [];
gdjs.FinishedCode.GDSeeLeaderboardObjects1= [];
gdjs.FinishedCode.GDSeeLeaderboardObjects2= [];
gdjs.FinishedCode.GDTransition1Objects1= [];
gdjs.FinishedCode.GDTransition1Objects2= [];
gdjs.FinishedCode.GDNewSpriteObjects1= [];
gdjs.FinishedCode.GDNewSpriteObjects2= [];
gdjs.FinishedCode.GDNewSprite2Objects1= [];
gdjs.FinishedCode.GDNewSprite2Objects2= [];


gdjs.FinishedCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Transition1"), gdjs.FinishedCode.GDTransition1Objects1);
{for(var i = 0, len = gdjs.FinishedCode.GDTransition1Objects1.length ;i < len;++i) {
    gdjs.FinishedCode.GDTransition1Objects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.4, "Circular", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.FinishedCode.eventsList1 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.FinishedCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("FinalScoreText"), gdjs.FinishedCode.GDFinalScoreTextObjects1);
{for(var i = 0, len = gdjs.FinishedCode.GDFinalScoreTextObjects1.length ;i < len;++i) {
    gdjs.FinishedCode.GDFinalScoreTextObjects1[i].setBBText("Your score is [i]" + gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber()) + "[/i] out of " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(0)) - 1) + ".");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.leaderboards.saveConnectedPlayerScore(runtimeScene, "35a79e82-461f-4e41-b5ae-e18d3ad18286", runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SeeLeaderboard"), gdjs.FinishedCode.GDSeeLeaderboardObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.FinishedCode.GDSeeLeaderboardObjects1.length;i<l;++i) {
    if ( gdjs.FinishedCode.GDSeeLeaderboardObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.FinishedCode.GDSeeLeaderboardObjects1[k] = gdjs.FinishedCode.GDSeeLeaderboardObjects1[i];
        ++k;
    }
}
gdjs.FinishedCode.GDSeeLeaderboardObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.leaderboards.displayLeaderboard(runtimeScene, "35a79e82-461f-4e41-b5ae-e18d3ad18286", true);
}}

}


};

gdjs.FinishedCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.FinishedCode.GDFinalScoreTextObjects1.length = 0;
gdjs.FinishedCode.GDFinalScoreTextObjects2.length = 0;
gdjs.FinishedCode.GDSeeLeaderboardObjects1.length = 0;
gdjs.FinishedCode.GDSeeLeaderboardObjects2.length = 0;
gdjs.FinishedCode.GDTransition1Objects1.length = 0;
gdjs.FinishedCode.GDTransition1Objects2.length = 0;
gdjs.FinishedCode.GDNewSpriteObjects1.length = 0;
gdjs.FinishedCode.GDNewSpriteObjects2.length = 0;
gdjs.FinishedCode.GDNewSprite2Objects1.length = 0;
gdjs.FinishedCode.GDNewSprite2Objects2.length = 0;

gdjs.FinishedCode.eventsList1(runtimeScene);
gdjs.FinishedCode.GDFinalScoreTextObjects1.length = 0;
gdjs.FinishedCode.GDFinalScoreTextObjects2.length = 0;
gdjs.FinishedCode.GDSeeLeaderboardObjects1.length = 0;
gdjs.FinishedCode.GDSeeLeaderboardObjects2.length = 0;
gdjs.FinishedCode.GDTransition1Objects1.length = 0;
gdjs.FinishedCode.GDTransition1Objects2.length = 0;
gdjs.FinishedCode.GDNewSpriteObjects1.length = 0;
gdjs.FinishedCode.GDNewSpriteObjects2.length = 0;
gdjs.FinishedCode.GDNewSprite2Objects1.length = 0;
gdjs.FinishedCode.GDNewSprite2Objects2.length = 0;


return;

}

gdjs['FinishedCode'] = gdjs.FinishedCode;
