gdjs.StartCode = {};
gdjs.StartCode.localVariables = [];
gdjs.StartCode.GDTitleObjects1= [];
gdjs.StartCode.GDTitleObjects2= [];
gdjs.StartCode.GDStart_9595ButtonObjects1= [];
gdjs.StartCode.GDStart_9595ButtonObjects2= [];
gdjs.StartCode.GDTransition1Objects1= [];
gdjs.StartCode.GDTransition1Objects2= [];
gdjs.StartCode.GDIllustrationObjects1= [];
gdjs.StartCode.GDIllustrationObjects2= [];
gdjs.StartCode.GDConnect_9595ButtonObjects1= [];
gdjs.StartCode.GDConnect_9595ButtonObjects2= [];
gdjs.StartCode.GDTitle2Objects1= [];
gdjs.StartCode.GDTitle2Objects2= [];
gdjs.StartCode.GDNewSpriteObjects1= [];
gdjs.StartCode.GDNewSpriteObjects2= [];


gdjs.StartCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Transition1"), gdjs.StartCode.GDTransition1Objects1);
{for(var i = 0, len = gdjs.StartCode.GDTransition1Objects1.length ;i < len;++i) {
    gdjs.StartCode.GDTransition1Objects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.4, "Circular", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.StartCode.eventsList1 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.StartCode.GDStart_9595ButtonObjects1);
{for(var i = 0, len = gdjs.StartCode.GDStart_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.StartCode.GDStart_9595ButtonObjects1[i].hide();
}
}
{ //Subevents
gdjs.StartCode.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Connect_Button"), gdjs.StartCode.GDConnect_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartCode.GDConnect_9595ButtonObjects1.length;i<l;++i) {
    if ( gdjs.StartCode.GDConnect_9595ButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartCode.GDConnect_9595ButtonObjects1[k] = gdjs.StartCode.GDConnect_9595ButtonObjects1[i];
        ++k;
    }
}
gdjs.StartCode.GDConnect_9595ButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.playerAuthentication.openAuthenticationWindow(runtimeScene);
}{gdjs.evtTools.sound.playSound(runtimeScene, "TransitionSound", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.playerAuthentication.hasLoggedIn();
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.StartCode.GDStart_9595ButtonObjects1);
{for(var i = 0, len = gdjs.StartCode.GDStart_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.StartCode.GDStart_9595ButtonObjects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.StartCode.GDStart_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartCode.GDStart_9595ButtonObjects1.length;i<l;++i) {
    if ( gdjs.StartCode.GDStart_9595ButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StartCode.GDStart_9595ButtonObjects1[k] = gdjs.StartCode.GDStart_9595ButtonObjects1[i];
        ++k;
    }
}
gdjs.StartCode.GDStart_9595ButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StartCode.GDStart_9595ButtonObjects1.length;i<l;++i) {
    if ( gdjs.StartCode.GDStart_9595ButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.StartCode.GDStart_9595ButtonObjects1[k] = gdjs.StartCode.GDStart_9595ButtonObjects1[i];
        ++k;
    }
}
gdjs.StartCode.GDStart_9595ButtonObjects1.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "TransitionSound", false, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Questions", false);
}}

}


};

gdjs.StartCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.StartCode.GDTitleObjects1.length = 0;
gdjs.StartCode.GDTitleObjects2.length = 0;
gdjs.StartCode.GDStart_9595ButtonObjects1.length = 0;
gdjs.StartCode.GDStart_9595ButtonObjects2.length = 0;
gdjs.StartCode.GDTransition1Objects1.length = 0;
gdjs.StartCode.GDTransition1Objects2.length = 0;
gdjs.StartCode.GDIllustrationObjects1.length = 0;
gdjs.StartCode.GDIllustrationObjects2.length = 0;
gdjs.StartCode.GDConnect_9595ButtonObjects1.length = 0;
gdjs.StartCode.GDConnect_9595ButtonObjects2.length = 0;
gdjs.StartCode.GDTitle2Objects1.length = 0;
gdjs.StartCode.GDTitle2Objects2.length = 0;
gdjs.StartCode.GDNewSpriteObjects1.length = 0;
gdjs.StartCode.GDNewSpriteObjects2.length = 0;

gdjs.StartCode.eventsList1(runtimeScene);
gdjs.StartCode.GDTitleObjects1.length = 0;
gdjs.StartCode.GDTitleObjects2.length = 0;
gdjs.StartCode.GDStart_9595ButtonObjects1.length = 0;
gdjs.StartCode.GDStart_9595ButtonObjects2.length = 0;
gdjs.StartCode.GDTransition1Objects1.length = 0;
gdjs.StartCode.GDTransition1Objects2.length = 0;
gdjs.StartCode.GDIllustrationObjects1.length = 0;
gdjs.StartCode.GDIllustrationObjects2.length = 0;
gdjs.StartCode.GDConnect_9595ButtonObjects1.length = 0;
gdjs.StartCode.GDConnect_9595ButtonObjects2.length = 0;
gdjs.StartCode.GDTitle2Objects1.length = 0;
gdjs.StartCode.GDTitle2Objects2.length = 0;
gdjs.StartCode.GDNewSpriteObjects1.length = 0;
gdjs.StartCode.GDNewSpriteObjects2.length = 0;


return;

}

gdjs['StartCode'] = gdjs.StartCode;
